# ProjetoIntegrador
## Oque é esse projeto?
### é um projeto finalizador do Curso senac tatuapé turma 22-02.
____
## Pré-requisito
* Qualquer forma de abrir o html
* visual code (opcional)

## Instalação
### É uma projeto simples de html e bootstrap, voce pode clonar este repósitorio e abrir com o live server do vscode.



## Criadores:
## ...
